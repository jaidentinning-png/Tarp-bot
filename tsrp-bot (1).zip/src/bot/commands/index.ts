import config from "./config";
import dashboard from "./dashboard";
import session from "./session";
import promote from "./promote";
import moderation from "./moderation";
import infractions from "./infractions";
import infract from "./infract";
import embed from "./embed";
import emblem from "./emblem";
import ticketpanel from "./ticketpanel";
import ticket from "./ticket";
import ticketlog from "./ticketlog";
import type { SlashCommand } from "../types";

export const commands: SlashCommand[] = [
  config,
  dashboard,
  session,
  promote,
  moderation,
  infractions,
  infract,
  embed,
  emblem,
  ticketpanel,
  ticket,
  ticketlog,
];
