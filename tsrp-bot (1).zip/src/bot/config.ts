import { db, guildConfigsTable, type GuildConfig } from "../db/index.js";
import { eq } from "drizzle-orm";

const cache = new Map<string, GuildConfig>();

export async function getGuildConfig(guildId: string): Promise<GuildConfig> {
  const cached = cache.get(guildId);
  if (cached) return cached;

  const [existing] = await db
    .select()
    .from(guildConfigsTable)
    .where(eq(guildConfigsTable.guildId, guildId))
    .limit(1);

  if (existing) {
    cache.set(guildId, existing);
    return existing;
  }

  const [created] = await db
    .insert(guildConfigsTable)
    .values({ guildId })
    .returning();

  if (!created) {
    throw new Error(`Failed to create guild config for ${guildId}`);
  }

  cache.set(guildId, created);
  return created;
}

export async function updateGuildConfig(
  guildId: string,
  values: Partial<Omit<GuildConfig, "id" | "guildId" | "createdAt" | "updatedAt">>,
): Promise<GuildConfig> {
  await getGuildConfig(guildId);

  const [updated] = await db
    .update(guildConfigsTable)
    .set(values)
    .where(eq(guildConfigsTable.guildId, guildId))
    .returning();

  if (!updated) {
    throw new Error(`Failed to update guild config for ${guildId}`);
  }

  cache.set(guildId, updated);
  return updated;
}
