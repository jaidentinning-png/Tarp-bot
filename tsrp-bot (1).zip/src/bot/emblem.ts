import { createCanvas } from "@napi-rs/canvas";

export interface EmblemOptions {
  text: string;
  subtext?: string | undefined;
  primaryColor: string;
  secondaryColor: string;
  shape: "shield" | "circle" | "badge";
}

function safeColor(value: string, fallback: string): string {
  return /^#?[0-9a-fA-F]{6}$/.test(value)
    ? value.startsWith("#")
      ? value
      : `#${value}`
    : fallback;
}

function drawShield(ctx: any, cx: number, cy: number, w: number, h: number) {
  const left = cx - w / 2;
  const right = cx + w / 2;
  const top = cy - h / 2;
  const bottom = cy + h / 2;
  ctx.beginPath();
  ctx.moveTo(left, top);
  ctx.lineTo(right, top);
  ctx.lineTo(right, top + h * 0.55);
  ctx.quadraticCurveTo(right, bottom, cx, bottom);
  ctx.quadraticCurveTo(left, bottom, left, top + h * 0.55);
  ctx.closePath();
}

function drawBadge(ctx: any, cx: number, cy: number, w: number, h: number) {
  const points = 8;
  const outerR = w / 2;
  const innerR = outerR * 0.88;
  ctx.beginPath();
  for (let i = 0; i < points * 2; i++) {
    const r = i % 2 === 0 ? outerR : innerR;
    const angle = (Math.PI / points) * i - Math.PI / 2;
    const x = cx + r * Math.cos(angle);
    const y = cy + r * Math.sin(angle) * (h / w);
    if (i === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  }
  ctx.closePath();
}

export function generateEmblem(options: EmblemOptions): Buffer {
  const size = 512;
  const canvas = createCanvas(size, size);
  const ctx = canvas.getContext("2d");

  const primary = safeColor(options.primaryColor, "#1e3a5f");
  const secondary = safeColor(options.secondaryColor, "#f2c94c");

  ctx.fillStyle = "#0d1117";
  ctx.fillRect(0, 0, size, size);

  const cx = size / 2;
  const cy = size / 2;
  const outerSize = size * 0.82;

  ctx.save();
  if (options.shape === "circle") {
    ctx.beginPath();
    ctx.arc(cx, cy, outerSize / 2, 0, Math.PI * 2);
  } else if (options.shape === "badge") {
    drawBadge(ctx, cx, cy, outerSize, outerSize);
  } else {
    drawShield(ctx, cx, cy, outerSize, outerSize * 1.05);
  }
  const gradient = ctx.createLinearGradient(0, cy - outerSize / 2, 0, cy + outerSize / 2);
  gradient.addColorStop(0, primary);
  gradient.addColorStop(1, "#05070a");
  ctx.fillStyle = gradient;
  ctx.fill();
  ctx.lineWidth = 8;
  ctx.strokeStyle = secondary;
  ctx.stroke();
  ctx.restore();

  ctx.save();
  const innerSize = outerSize * 0.82;
  if (options.shape === "circle") {
    ctx.beginPath();
    ctx.arc(cx, cy, innerSize / 2, 0, Math.PI * 2);
  } else if (options.shape === "badge") {
    drawBadge(ctx, cx, cy, innerSize, innerSize);
  } else {
    drawShield(ctx, cx, cy, innerSize, innerSize * 1.05);
  }
  ctx.lineWidth = 4;
  ctx.strokeStyle = secondary;
  ctx.globalAlpha = 0.6;
  ctx.stroke();
  ctx.restore();

  const mainText = options.text.toUpperCase().slice(0, 12);
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillStyle = secondary;
  let fontSize = mainText.length > 6 ? 56 : 74;
  ctx.font = `bold ${fontSize}px sans-serif`;
  while (ctx.measureText(mainText).width > outerSize * 0.72 && fontSize > 24) {
    fontSize -= 4;
    ctx.font = `bold ${fontSize}px sans-serif`;
  }
  ctx.fillText(mainText, cx, cy - (options.subtext ? 18 : 0));

  if (options.subtext) {
    ctx.font = "600 26px sans-serif";
    ctx.fillStyle = "#ffffff";
    ctx.fillText(options.subtext.toUpperCase().slice(0, 24), cx, cy + 42);
  }

  return canvas.toBuffer("image/png");
}
