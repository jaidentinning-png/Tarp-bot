import fs from "fs";
import path from "path";
import { createClient } from "@libsql/client";
import { drizzle } from "drizzle-orm/libsql";
import * as schema from "./schema";

const sqlitePath = process.env.SQLITE_PATH || "./data/tsrp-bot.db";
const resolvedPath = path.resolve(sqlitePath);
fs.mkdirSync(path.dirname(resolvedPath), { recursive: true });

export const client = createClient({ url: `file:${resolvedPath}` });
export const db = drizzle(client, { schema });

export * from "./schema";
